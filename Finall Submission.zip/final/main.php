<?php
echo '<a href="/default.asp">Home</a> -
<a href="/html/default.asp">HTML Tutorial</a> -
<a href="/css/default.asp">CSS Tutorial</a> -
<a href="/js/default.asp">JavaScript Tutorial</a> -
<a href="default.asp">PHP Tutorial</a>';
?>

<nav>
        <div id="nav">
		            <ul>
						<li><a href="#">Tutorial</a></li>
						<li><a href="#">Students &raquo;</a>
							<ul>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item  &raquo;</a>
									<ul>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
										<li><a href="#">Sub Dropdown Item</a></li>
									</ul>							
								</li>
								<li><a href="#">Dropdown Item</a></li>
								<li><a href="#">Dropdown Item</a></li>
							</ul>
						</li>
						<li><a href="#">Job</a></li>
						<li><a href="#">Courses</a></li>
					</ul>
				</div>
			</nav>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>seek coding</title>
    <link rel="stylesheet" href="firstpage1.css">
    <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
    <div class="full-page">
 <h1>Welcome to coding land!</h1><hr>
<p>Some text.</p>
<p>Some more text.</p>
<?php include 'welcome.php';?>
</div>
    
</body>
</html>
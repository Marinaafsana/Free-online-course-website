<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>seek coding</title>
    <link rel="stylesheet" href="algo.css">
    <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">

 <style>

 h2 {
     text-align: center;
	color: balck;
}
 h1 {
      margin-left: 20%;
	color: yellow;
}
img {
  display : block;
  margin-left: -5%%;
  margin-right: auto;
  
}
#id{

    color :#EEF1F1;
}


</style>
</head>
<body>
    <div class="full-page">
        
        <div class="sub-page">
            
            </div> 
            <div class ="header">
              
				<img src="alogo.png" alt="logo is loading" width="auto" height="100px">
             
            </div>
            <div class="names">
                <h2>Algorithm</h2>
                <ul id = 'lan'>
            <h1><a  href="#greedyAlgorithm">Greedy Algorithm</a></h1>
            <h1><a href="#sorting">Sorting</a></h1>
            <h1><a href="#searching">Searching</a></h1>
            <h1><a href="#dp">Dynamic Programming</a></h1>
              </ul>
            
            
            </div>
          
    </div>
    
   
</html>
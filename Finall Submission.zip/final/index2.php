<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CodingLand</title>
    <link rel="stylesheet" href="land.css">
    <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
    <div class="full-page">
    <br>
        <!-- <?php echo $_SESSION[""] ?> -->
        <div class="sub-page">
            <div class="navigation-bar">
            </div>
            <div class="row">
                <div class="col-1">
                    <div class="form-box">
                        <div class="form">
                            <form class="login-form">
				            </form>  
			             </div>
	                </div>
                </div>
                <div class="col-1">
                    <p class='defination'>
                          KNOWLEDGE IS POWER! THERE IS NO LIMIT TO THE KNOWLEDGE THAT ONE CAN HAVE.A NUMBER OF PROBLEMS AND COURSES ARE WAITING FOR YOU.COME WITH US AND GAIN SOME KNOWLEDGE ABOUT COMPUTER SCIENCE.
                          Welcome to coding land!</p><br>
                <input type=button onClick="parent.location='login.php'" value='Login'>
               <a href="" class="button"></a> 
                </div>
            </div>
        </div>
    </div>
</body>
</html>
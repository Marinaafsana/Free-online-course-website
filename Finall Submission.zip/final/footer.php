<?php
echo "<p style=color:#148096;>Copyright &copy; 1999-" . date("Y") . " CodingLand.com</p>";
?>